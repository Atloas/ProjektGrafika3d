#include <iostream>

#include "Engine.h"

int main()
{
	Engine engine;
	engine.run();
}