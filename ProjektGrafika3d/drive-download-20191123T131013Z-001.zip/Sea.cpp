#include "Sea.h"

#include <SFML\OpenGL.hpp>

Sea::Sea(Field *playField)
{
	xMin = playField->getXMin();
	xMax = playField->getXMax();
	yMin = playField->getYMin();
	yMax = playField->getYMax();
}

void Sea::draw()
{
	glBegin(GL_TRIANGLES);
	glColor3f(0.5f, 0.5f, 0.9f);

	glVertex3f(xMin, yMin, 0.0f);
	glVertex3f(xMax, yMin, 0.0f);
	glVertex3f(xMax, yMax, 0.0f);

	glVertex3f(xMax, yMax, 0.0f);
	glVertex3f(xMin, yMax, 0.0f);
	glVertex3f(xMin, yMin, 0.0f);
	glEnd();
}