#pragma once

#include "Field.h"

class Sea
{
public:
	Sea(Field *playField);

	virtual void draw();

private:
	float xMin, xMax, yMin, yMax;
};