#pragma once

#define PLAYER_GROUP 1
#define PLAYER_BULLET_GROUP 2
#define ENEMY_GROUP 4
#define ENEMY_BULLET_GROUP 8